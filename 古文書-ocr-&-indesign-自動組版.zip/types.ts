
import { Database, Json } from './services/database.types';

export type StructuredContentType = 'title' | 'paragraph' | 'author' | 'annotation';

export interface StructuredContent {
  id: string;
  type: StructuredContentType;
  content: string;
  bounds?: {
    x: number;
    y: number;
    width: number;
    height: number;
  };
}

export enum ProcessState {
  Uploaded = 'uploaded',
  Processing = 'processing',
  Completed = 'completed',
  Error = 'error',
}

export type PaperFormatKey = 'Shiroku-ban' | 'Kiku-ban' | 'Shinsho-ban' | 'Bunko-ban' | 'B6' | 'A5' | 'B5' | 'AB-ban';

export interface PaperFormat {
  nameJP: string;
  width_mm: number;
  height_mm: number;
}

export type ExportStatus = 'idle' | 'exporting' | 'success' | 'error';

export interface FormattingOptions {
  fontFamily: 'serif' | 'sans-serif';
  fontSize: number;
  lineHeight: number;
}


// --- NEW SCHEMA-BASED TYPES ---

export type Project = Database['public']['Tables']['projects']['Row'];

export type OcrDocument = Database['public']['Tables']['ocr_documents']['Row'] & {
  // Demo flag
  isDemo?: boolean;

  // UI state for export and formatting
  exportStatus?: ExportStatus;
  exportUrl?: string;
  exportFilename?: string;
  formattingOptions?: FormattingOptions;
};

export type OcrDocumentVersion = Database['public']['Tables']['ocr_document_versions']['Row'];
