
import React, { useState, useCallback, useEffect } from 'react';
import { StructuredContent, ProcessState, PaperFormatKey, OcrDocument, ExportStatus, FormattingOptions, Project, OcrDocumentVersion, StructuredContentType } from './types';
import { performOcr, adjustTextWithAI } from './services/geminiService';
import { generateIdmlFile } from './services/idmlService';
import FileUpload from './components/FileUpload';
import { HeaderIcon, RestartIcon, PlusIcon, ChevronLeftIcon, XIcon, CheckIcon } from './components/icons';
import ImageEditor from './components/ImageEditor';
import DiffViewer from './components/DiffViewer';
import Pagination from './components/Pagination';
import { demoContent, demoImage } from './services/demoData';
import PaperFormatSelector from './components/PaperFormatSelector';
import { DEFAULT_PAPER_FORMAT, PAPER_FORMATS } from './constants';
import ProjectList from './components/JobList'; // Re-using JobList as ProjectList
import JobProgress from './components/JobProgress';
import UrlInput from './components/UrlInput';
import { dbService } from './services/dbService';
import { supabase } from './services/supabaseClient';
import type { Session, User } from '@supabase/supabase-js';
import { type Database, Json } from './services/database.types';
import ThemeToggle from './components/ThemeToggle';

declare const pdfjsLib: any;

type ViewState =
  | { view: 'project_list' }
  | { view: 'creation' }
  | { view: 'document_list'; projectId: string }
  | { view: 'document_detail'; projectId: string; documentId: string };

const App: React.FC = () => {
  const [viewState, setViewState] = useState<ViewState>({ view: 'project_list' });
  const [session, setSession] = useState<Session | null>(null);
  const [authInitialized, setAuthInitialized] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  const user = session?.user;

  useEffect(() => {
    setAuthInitialized(false);
    supabase.auth.getSession().then(({ data, error }) => {
      if (error) {
        console.error("Error getting session:", error);
        setError("既存セッションの確認中にエラーが発生しました。");
      } else {
        setSession(data.session);
      }
      setAuthInitialized(true);
    });

    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      setSession(session);
      if (session) setError(null);
    });

    return () => subscription.unsubscribe();
  }, []);
  
  useEffect(() => {
    if (authInitialized && !session && !error) {
      const signIn = async () => {
        try {
          const { error: signInError } = await supabase.auth.signInAnonymously();
          if (signInError) {
              console.error("Error signing in anonymously:", signInError);
              setError(signInError.message.includes('disabled')
                ? "匿名サインインが無効です。このアプリが機能するには、Supabaseプロジェクトで匿名認証を有効にする必要があります。"
                : `認証セッションの確立に失敗しました: ${signInError.message}`);
          }
        } catch(e) {
            const message = e instanceof Error ? e.message : '不明なエラーです。';
            setError(`認証中に予期せぬエラーが発生しました: ${message}`);
        }
      };
      signIn();
    }
  }, [authInitialized, session, error]);

  const navigateToProjectList = () => setViewState({ view: 'project_list' });
  const navigateToCreation = () => setViewState({ view: 'creation' });
  const navigateToDocumentList = (projectId: string) => setViewState({ view: 'document_list', projectId });
  const handleSelectDocument = (projectId: string, documentId: string) => setViewState({ view: 'document_detail', projectId, documentId });

  const navigateBack = () => {
    if (viewState.view === 'document_detail') {
      setViewState({ view: 'document_list', projectId: viewState.projectId });
    } else if (viewState.view === 'document_list' || viewState.view === 'creation') {
      setViewState({ view: 'project_list' });
    }
  };

  const handleCreateProjectAndDocument = async (
    projectName: string,
    documentTitle: string,
    pdfFile: File,
    formatKey: PaperFormatKey
  ) => {
    if (!user) {
      alert("認証エラー: ユーザーセッションが見つかりません。");
      return;
    }
  
    try {
      // 1. Create Project
      const newProject = await dbService.addProject({ project_name: projectName });
  
      // 2. Create Document record
      const paperFormat = PAPER_FORMATS[formatKey];
      const docData: Omit<Database['public']['Tables']['ocr_documents']['Insert'], 'id' | 'created_at' | 'updated_at' | 'status' | 'current_version'> = {
        project_id: newProject.id,
        title: documentTitle,
        original_filename: pdfFile.name,
        paper_width_mm: paperFormat.width_mm,
        paper_height_mm: paperFormat.height_mm,
        total_pages: 0, // Will be updated after upload
        error: null,
        progress_message: 'ドキュメントを作成中...',
        processed_pages: null,
      };
      const newDoc = await dbService.addDocument(docData);
      
      // 3. Navigate to document list view so user can see progress
      navigateToDocumentList(newProject.id);
  
      // 4. Start async processing
      const process = async () => {
        let currentDoc = await dbService.updateDocument({ id: newDoc.id, status: ProcessState.Processing, progress_message: 'PDFをアップロード中...'});

        const { path: pdfStoragePath } = await dbService.uploadPdf(pdfFile, user.id, newProject.id);
        
        currentDoc = await dbService.updateDocument({ id: currentDoc.id, progress_message: 'PDFアップロード完了。ページ数を解析中...'});

        const pdfUrl = dbService.getPdfPublicUrl(pdfStoragePath);
        const pdfDocHandle = await pdfjsLib.getDocument(pdfUrl).promise;
        
        currentDoc = await dbService.updateDocument({ 
          id: currentDoc.id, 
          total_pages: pdfDocHandle.numPages
        });
        
        await processDocument(currentDoc, pdfDocHandle, user.id, newProject.id);
      };
      
      process().catch(err => {
        console.error("Error during async document processing:", err);
        const errorMessage = err instanceof Error ? err.message : String(err);
        dbService.updateDocument({ id: newDoc.id, status: ProcessState.Error, error: `処理の初期化に失敗: ${errorMessage}` });
      });
  
    } catch (err) {
      console.error("Error creating project and document:", err);
      alert(`作成中にエラーが発生しました: ${err instanceof Error ? err.message : err}`);
      navigateToProjectList(); // Go back to safety on failure
    }
  };
  
  const processDocument = async (doc: OcrDocument, pdfDocHandle: any, userId: string, projectId: string) => {
    await dbService.updateDocument({ id: doc.id, status: ProcessState.Processing, progress_message: 'OCR処理を開始します...'});

    const layout_json: Record<string, any[]> = {};

    try {
        for (let pageNum = 1; pageNum <= pdfDocHandle.numPages; pageNum++) {
            await dbService.updateDocument({ id: doc.id, processed_pages: pageNum - 1, progress_message: `ページ ${pageNum}/${pdfDocHandle.numPages} を処理中...` });

            const page = await pdfDocHandle.getPage(pageNum);
            const viewport = page.getViewport({ scale: 2.0 });
            const canvas = document.createElement('canvas');
            canvas.height = viewport.height;
            canvas.width = viewport.width;
            const context = canvas.getContext('2d')!;
            await page.render({ canvasContext: context, viewport }).promise;
            const imageDataUrl = canvas.toDataURL('image/png');

            await dbService.uploadPageImage(imageDataUrl, projectId, doc.id, pageNum, userId);
            
            const content = await performOcr(imageDataUrl);
            layout_json[String(pageNum)] = content;
        }

        const versionData: Database['public']['Tables']['ocr_document_versions']['Insert'] = {
            document_id: doc.id,
            version_number: 1,
            changelog: 'Initial version from OCR',
            layout_json: layout_json,
            created_by: userId,
        };
        const newVersion = await dbService.addDocumentVersion(versionData);

        await dbService.updateDocument({
            id: doc.id,
            status: ProcessState.Completed,
            processed_pages: pdfDocHandle.numPages,
            progress_message: '処理が完了しました。',
            current_version: newVersion.id,
        });

    } catch (err) {
        console.error(err);
        const errorMessage = err instanceof Error ? err.message : '不明なエラー';
        await dbService.updateDocument({ id: doc.id, status: ProcessState.Error, error: errorMessage });
    }
  };
  
  if (!authInitialized || !session) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-gray-50 dark:bg-gray-900 text-center p-4">
        {error ? (
          <div className="bg-red-100 border border-red-400 text-red-700 dark:text-red-200 dark:bg-red-900/50 dark:border-red-700 px-4 py-3 rounded relative text-left max-w-lg" role="alert">
            <strong className="font-bold">認証エラー:</strong>
            <span className="block sm:inline ml-2">{error}</span>
          </div>
        ) : (
          <div>
            <div className="w-16 h-16 border-4 border-t-4 border-t-indigo-500 border-gray-200 dark:border-gray-600 rounded-full animate-spin mx-auto"></div>
            <p className="mt-4 text-gray-600 dark:text-gray-300">安全なセッションを準備しています...</p>
          </div>
        )}
      </div>
    );
  }

  const renderContent = () => {
    switch (viewState.view) {
        case 'document_detail':
            return <DocumentDetailView key={viewState.documentId} user={user!} {...viewState} />;
        case 'document_list':
            return <DocumentListView key={viewState.projectId} user={user!} onSelectDocument={handleSelectDocument} {...viewState} />;
        case 'creation':
            return <CreationView user={user!} onCreate={handleCreateProjectAndDocument} />;
        case 'project_list':
        default:
            return <ProjectList user={user!} onSelectProject={navigateToDocumentList} onStartCreation={navigateToCreation} />;
    }
  };
  
  const getHeaderText = () => {
      if (viewState.view === 'document_detail') return 'ドキュメント詳細';
      if (viewState.view === 'document_list') return 'ドキュメント一覧';
      if (viewState.view === 'creation') return '新規プロジェクトとドキュメントの作成';
      return '古文書OCR & InDesign 自動組版';
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 font-sans text-gray-900 dark:text-gray-200">
      <header className="bg-white dark:bg-gray-800 shadow-md p-4 flex items-center justify-between sticky top-0 z-10">
        <div className="flex items-center space-x-3">
            {viewState.view !== 'project_list' && (
                <button onClick={navigateBack} className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-700 text-gray-700 dark:text-gray-300" aria-label="戻る">
                    <ChevronLeftIcon className="w-6 h-6" />
                </button>
            )}
            <HeaderIcon />
            <h1 className="text-xl md:text-2xl font-bold text-gray-800 dark:text-white truncate">
                {getHeaderText()}
            </h1>
        </div>
        <div className="flex items-center">
            <ThemeToggle />
        </div>
      </header>

      <main className="p-4 sm:p-6 lg:p-8">
        {renderContent()}
      </main>
    </div>
  );
};

// --- Creation View ---
interface CreationViewProps {
    user: User;
    onCreate: (projectName: string, documentTitle: string, file: File, format: PaperFormatKey) => void;
}

const CreationView: React.FC<CreationViewProps> = ({ onCreate }) => {
    const [projectName, setProjectName] = useState('');
    const [documentTitle, setDocumentTitle] = useState('');
    const [pdfFile, setPdfFile] = useState<File | null>(null);
    const [paperFormat, setPaperFormat] = useState<PaperFormatKey>(DEFAULT_PAPER_FORMAT);
    const [isCreating, setIsCreating] = useState(false);
    
    const [pdfPreviewUrl, setPdfPreviewUrl] = useState<string | null>(null);
    const [isGeneratingPreview, setIsGeneratingPreview] = useState(false);
    const [previewError, setPreviewError] = useState<string | null>(null);

    const handleFileSelect = useCallback(async (file: File) => {
        setPdfFile(file);
        // Auto-populate names, removing extension for project name
        const nameWithoutExt = file.name.replace(/\.[^/.]+$/, "");
        setProjectName(prev => prev || nameWithoutExt);
        setDocumentTitle(prev => prev || file.name);
        
        // Generate preview
        setPdfPreviewUrl(null);
        setPreviewError(null);
        setIsGeneratingPreview(true);
        try {
            const fileBuffer = await file.arrayBuffer();
            const pdfDoc = await pdfjsLib.getDocument({ data: fileBuffer }).promise;
            const page = await pdfDoc.getPage(1);
            const viewport = page.getViewport({ scale: 1.0 });
            const canvas = document.createElement('canvas');
            const context = canvas.getContext('2d')!;
            canvas.height = viewport.height;
            canvas.width = viewport.width;
            await page.render({ canvasContext: context, viewport: viewport }).promise;
            setPdfPreviewUrl(canvas.toDataURL('image/png'));
        } catch (e) {
            console.error("Failed to generate PDF preview", e);
            setPreviewError('PDFのプレビュー生成に失敗しました。ファイルが破損している可能性があります。');
        } finally {
            setIsGeneratingPreview(false);
        }
    }, []);

    const handleClearFile = () => {
        setPdfFile(null);
        setPdfPreviewUrl(null);
        setPreviewError(null);
    };
    
    const handleSubmit = () => {
        if (!projectName.trim() || !documentTitle.trim() || !pdfFile) {
            alert('すべての項目を入力してください。');
            return;
        }
        setIsCreating(true);
        onCreate(projectName, documentTitle, pdfFile, paperFormat);
    };

    return (
        <div className="max-w-4xl mx-auto space-y-8 p-8 bg-white dark:bg-gray-800 rounded-lg shadow-lg">
            <div>
                <h3 className="text-2xl font-bold text-gray-800 dark:text-white mb-2">ステップ1: プロジェクトとドキュメント情報の入力</h3>
                <p className="text-gray-600 dark:text-gray-400">PDFをアップロードすると、プロジェクト名とドキュメント名が自動入力されます。</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                    <label htmlFor="project-name" className="block text-sm font-medium text-gray-700 dark:text-gray-300">プロジェクト名</label>
                    <input
                        type="text"
                        id="project-name"
                        value={projectName}
                        onChange={e => setProjectName(e.target.value)}
                        className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm dark:bg-gray-700 dark:text-white dark:border-gray-600"
                        placeholder="例: 夏目漱石『吾輩は猫である』"
                        required
                    />
                </div>
                <div>
                    <label htmlFor="document-title" className="block text-sm font-medium text-gray-700 dark:text-gray-300">ドキュメント名</label>
                    <input
                        type="text"
                        id="document-title"
                        value={documentTitle}
                        onChange={e => setDocumentTitle(e.target.value)}
                        className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm dark:bg-gray-700 dark:text-white dark:border-gray-600"
                        placeholder="例: wagahai_v1.pdf"
                        required
                    />
                </div>
            </div>

            <div>
                <h3 className="text-2xl font-bold text-gray-800 dark:text-white mb-2">ステップ2: 原稿ファイルの選択</h3>
                {pdfFile ? (
                    <div className="mt-2 p-4 border-2 border-dashed rounded-lg border-gray-300 dark:border-gray-600 flex items-start space-x-4 relative">
                        {isGeneratingPreview && (
                            <div className="w-24 h-32 flex items-center justify-center bg-gray-100 dark:bg-gray-700 rounded">
                                <div className="w-6 h-6 border-2 border-t-2 border-t-indigo-500 border-gray-400 rounded-full animate-spin"></div>
                            </div>
                        )}
                        {previewError && (
                            <div className="w-24 h-32 flex flex-col items-center justify-center bg-red-50 dark:bg-red-900/50 rounded text-center p-2">
                                <p className="text-red-500 text-xs">{previewError}</p>
                            </div>
                        )}
                        {pdfPreviewUrl && (
                            <img src={pdfPreviewUrl} alt="PDF first page preview" className="w-24 h-auto border dark:border-gray-500 rounded-sm shadow-sm" />
                        )}
                        <div className="flex-grow">
                            <p className="font-semibold text-gray-800 dark:text-white break-all">{pdfFile.name}</p>
                            <p className="text-sm text-gray-500 dark:text-gray-400">{(pdfFile.size / 1024 / 1024).toFixed(2)} MB</p>
                        </div>
                        <button onClick={handleClearFile} className="absolute top-2 right-2 p-1 text-gray-500 hover:text-red-600 dark:hover:text-red-400 rounded-full hover:bg-gray-100 dark:hover:bg-gray-700" aria-label="ファイルを削除">
                            <XIcon className="w-5 h-5" />
                        </button>
                    </div>
                ) : (
                    <FileUpload onFileSelect={handleFileSelect} />
                )}
            </div>

            <div>
                <h3 className="text-2xl font-bold text-gray-800 dark:text-white mb-2">ステップ3: 用紙フォーマットの選択</h3>
                <PaperFormatSelector selectedFormat={paperFormat} onFormatChange={setPaperFormat} />
            </div>
            
            <div className="pt-8 border-t border-gray-200 dark:border-gray-700 flex justify-end">
                <button
                    onClick={handleSubmit}
                    disabled={!projectName.trim() || !documentTitle.trim() || !pdfFile || isCreating}
                    className="flex items-center justify-center px-6 py-3 bg-indigo-600 text-white font-semibold rounded-lg shadow-md hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 disabled:bg-gray-400 dark:disabled:bg-gray-500 disabled:cursor-not-allowed w-full md:w-auto"
                >
                    {isCreating ? '作成中...' : '作成して処理を開始'}
                </button>
            </div>
        </div>
    );
};


// --- Document List View ---
interface DocumentListViewProps {
    user: User;
    projectId: string;
    onSelectDocument: (projectId: string, documentId: string) => void;
}

const DocumentListView: React.FC<DocumentListViewProps> = ({ user, projectId, onSelectDocument }) => {
    const [project, setProject] = useState<Project | null>(null);
    const [documents, setDocuments] = useState<OcrDocument[]>([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);

    const fetchDocuments = useCallback(async (isInitialLoad = false) => {
        if (isInitialLoad) setLoading(true);
        try {
            if (isInitialLoad) {
                const projectData = (await dbService.getProjects()).find(p => p.id === projectId);
                setProject(projectData || null);
            }
            const docs = await dbService.getDocumentsForProject(projectId);
            setDocuments(docs);
        } catch (err) {
            setError(err instanceof Error ? err.message : 'ドキュメントの読み込みに失敗しました。');
        } finally {
            if (isInitialLoad) setLoading(false);
        }
    }, [projectId]);

    useEffect(() => {
        fetchDocuments(true);
    }, [fetchDocuments]);

    useEffect(() => {
        const channel = supabase
            .channel(`db-documents-in-project-${projectId}`)
            .on<Database['public']['Tables']['ocr_documents']['Row']>(
                'postgres_changes',
                {
                    event: '*',
                    schema: 'public',
                    table: 'ocr_documents',
                    filter: `project_id=eq.${projectId}`
                },
                () => {
                    fetchDocuments(false);
                }
            )
            .subscribe();

        return () => {
            supabase.removeChannel(channel);
        };
    }, [projectId, fetchDocuments]);


    if (loading) return <div className="text-center p-8">読み込み中...</div>;
    if (error) return <div className="text-red-500 dark:text-red-400">エラー: {error}</div>;

    return (
        <div className="max-w-7xl mx-auto">
            <div className="flex justify-between items-center mb-6">
                <h2 className="text-2xl font-bold text-gray-800 dark:text-white">
                    プロジェクト: {project?.project_name || '...'}
                </h2>
            </div>

            <div className="bg-white dark:bg-gray-800 shadow-md rounded-lg overflow-x-auto">
                <table className="w-full text-sm text-left text-gray-500 dark:text-gray-400">
                    <thead className="text-xs text-gray-700 dark:text-gray-400 bg-gray-50 dark:bg-gray-700/50">
                        <tr>
                            <th scope="col" className="px-6 py-3 font-semibold">ドキュメント名</th>
                            <th scope="col" className="px-6 py-3 font-semibold">作成日</th>
                            <th scope="col" className="px-6 py-3 font-semibold">ページ数</th>
                            <th scope="col" className="px-6 py-3 font-semibold" style={{minWidth: '200px'}}>ステータス</th>
                        </tr>
                    </thead>
                    <tbody>
                        {documents.length > 0 ? documents.map(d => {
                            const isProcessing = d.status === ProcessState.Processing.toString();
                            const isCompleted = d.status === ProcessState.Completed.toString();
                            const isError = d.status === ProcessState.Error.toString();
                            const progress = d.total_pages > 0 ? (((d.processed_pages || 0)) / d.total_pages) * 100 : 0;
                           
                            return (
                                <tr key={d.id} 
                                    className={`border-b dark:border-gray-700 transition-colors ${
                                        isError 
                                        ? 'bg-red-50 dark:bg-red-900/20'
                                        : 'bg-white dark:bg-gray-800'
                                    } hover:bg-gray-50 dark:hover:bg-gray-700/50`}
                                >
                                    <th scope="row" className="px-6 py-4 font-medium text-gray-900 dark:text-white whitespace-nowrap">
                                    {isProcessing ? (
                                        <span className="text-gray-500">{d.title}</span>
                                    ) : (
                                        <button
                                            onClick={() => onSelectDocument(projectId, d.id)}
                                            className="text-left font-semibold text-indigo-600 dark:text-indigo-400 hover:underline focus:outline-none bg-transparent border-none p-0 cursor-pointer"
                                            title={isError ? d.error || 'エラー詳細を表示' : 'ドキュメント詳細を表示'}
                                        >
                                            {d.title}
                                        </button>
                                    )}
                                    </th>
                                    <td className="px-6 py-4">
                                        {new Date(d.created_at).toLocaleDateString()}
                                    </td>
                                    <td className="px-6 py-4">
                                        {d.total_pages > 0 ? `${d.total_pages}ページ` : '未定'}
                                    </td>
                                    <td className="px-6 py-4">
                                        {isProcessing ? (
                                            <div>
                                                <div className="flex justify-between mb-1">
                                                    <span className="text-xs font-medium text-indigo-700 dark:text-indigo-300 truncate pr-2" title={d.progress_message || undefined}>{d.progress_message}</span>
                                                    <span className="text-xs font-medium text-indigo-700 dark:text-indigo-300">{Math.round(progress)}%</span>
                                                </div>
                                                <div className="w-full bg-gray-200 rounded-full h-1.5 dark:bg-gray-600">
                                                    <div className="bg-indigo-600 h-1.5 rounded-full" style={{width: `${progress}%`}}></div>
                                                </div>
                                            </div>
                                        ) : isError ? (
                                             <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300">
                                                <XIcon className="w-3 h-3 mr-1.5" />
                                                処理エラー
                                            </span>
                                        ) : isCompleted ? (
                                            <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300">
                                                <CheckIcon className="w-3 h-3 mr-1.5" />
                                                完了
                                            </span>
                                        ) : (
                                            <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-300">
                                                待機中
                                            </span>
                                        )}
                                    </td>
                                </tr>
                            );
                        }) : (
                            <tr>
                                <td colSpan={4} className="px-6 py-16 text-center text-gray-500 dark:text-gray-400">
                                    このプロジェクトにはドキュメントがありません。<br/>
                                    プロジェクト一覧画面に戻り、「新規プロジェクト」から追加してください。
                                </td>
                            </tr>
                        )}
                    </tbody>
                </table>
            </div>
        </div>
    );
};

// --- Document Detail View ---
interface DocumentDetailViewProps {
    user: User;
    projectId: string;
    documentId: string;
}

const DocumentDetailView: React.FC<DocumentDetailViewProps> = ({ user, projectId, documentId }) => {
    const [doc, setDoc] = useState<OcrDocument | null>(null);
    const [versions, setVersions] = useState<OcrDocumentVersion[]>([]);
    const [activeVersion, setActiveVersion] = useState<OcrDocumentVersion | null>(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);

    const [currentPage, setCurrentPage] = useState(1);
    const [isEditingImage, setIsEditingImage] = useState(false);
    const [isAdjusting, setIsAdjusting] = useState(false);
    
    const [originalImageUrl, setOriginalImageUrl] = useState<string | null>(null);

    useEffect(() => {
        const loadData = async () => {
            setLoading(true);
            try {
                const documentData = await dbService.getDocument(documentId);
                if (!documentData) {
                    setError("ドキュメントが見つかりません。");
                    return;
                }

                const versionsData = await dbService.getDocumentVersions(documentId);
                setDoc(documentData);
                setVersions(versionsData);
                
                // If a version is completed, set it as active.
                if (documentData.current_version && versionsData.length > 0) {
                    const current = versionsData.find(v => v.id === documentData.current_version) || versionsData[0];
                    setActiveVersion(current);
                }

            } catch (e) {
                setError(e instanceof Error ? e.message : "データの読み込みに失敗しました。");
            } finally {
                setLoading(false);
            }
        };
        
        loadData();
    
        // Set up real-time subscription
        const channel = supabase
            .channel(`db-ocr-documents-realtime-${documentId}`)
            .on<Database['public']['Tables']['ocr_documents']['Row']>(
                'postgres_changes',
                {
                    event: 'UPDATE',
                    schema: 'public',
                    table: 'ocr_documents',
                    filter: `id=eq.${documentId}`
                },
                (payload) => {
                    const updatedDocFromDb = payload.new;
                    setDoc(prevDoc => {
                        if (!prevDoc) return null;
                        
                        // When processing completes, fetch versions again
                        if (prevDoc.status !== ProcessState.Completed && updatedDocFromDb.status === ProcessState.Completed) {
                            dbService.getDocumentVersions(documentId).then(versionsData => {
                                setVersions(versionsData);
                                if (versionsData.length > 0) {
                                    const current = versionsData.find(v => v.id === updatedDocFromDb.current_version) || versionsData[0];
                                    setActiveVersion(current);
                                }
                            });
                        }

                        return {
                            ...prevDoc,
                            ...updatedDocFromDb,
                            status: updatedDocFromDb.status as ProcessState,
                        };
                    });
                }
            )
            .subscribe((status, err) => {
                if (status === 'CHANNEL_ERROR') {
                    console.error(`Subscription error for document ${documentId}:`, err);
                    setError('リアルタイム更新の接続に失敗しました。');
                }
            });
    
        // Clean up subscription on unmount
        return () => {
            supabase.removeChannel(channel);
        };
    }, [documentId]);
    
    useEffect(() => {
      const fetchImage = async () => {
        if (doc && doc.id && (doc.status === ProcessState.Completed.toString() || doc.status === ProcessState.Error.toString())) {
          try {
            const imagePath = `${user.id}/${doc.project_id}/${doc.id}/page_${currentPage}.png`;
            const publicUrl = dbService.getPageImagePublicUrl(imagePath);
            const response = await fetch(publicUrl, { method: 'HEAD' });
            if (response.ok) {
              setOriginalImageUrl(publicUrl);
            } else {
              setOriginalImageUrl(null);
            }
          } catch(e) {
            console.warn("Could not fetch page image", e);
            setOriginalImageUrl(null);
          }
        }
      };
      fetchImage();
    }, [doc, currentPage, user]);

    const updateDocumentState = useCallback(async (update: Partial<OcrDocument>) => {
        if (!doc) return;
        
        const updatedDocInDb = await dbService.updateDocument({ id: doc.id, ...update });
        
        setDoc(updatedDocInDb);
        return updatedDocInDb;
    }, [doc]);


    const handleAdjust = useCallback(async (prompt: string) => {
        if (!activeVersion || !doc || !user || isAdjusting) return;
        
        setIsAdjusting(true);
        updateDocumentState({ progress_message: `ページ${currentPage}をAIで調整中...` });

        try {
            const pageKey = String(currentPage);
            const layout = activeVersion.layout_json as unknown as Record<string, StructuredContent[]>;
            const currentContent = layout[pageKey];
            if (!currentContent) throw new Error("調整するコンテンツがありません。");

            const adjustedContent = await adjustTextWithAI(currentContent, prompt);

            const newVersionNumber = Math.max(...versions.map(v => v.version_number), 0) + 1;
            const newLayoutJson = { ...layout, [pageKey]: adjustedContent };

            const newVersionData: Database['public']['Tables']['ocr_document_versions']['Insert'] = {
                document_id: doc.id,
                version_number: newVersionNumber,
                changelog: `AI Adjustment: "${prompt.substring(0, 50)}${prompt.length > 50 ? '...' : ''}"`,
                layout_json: newLayoutJson as unknown as Json,
                created_by: user.id,
            };

            const newVersion = await dbService.addDocumentVersion(newVersionData);
            
            await updateDocumentState({
                current_version: newVersion.id,
                progress_message: `バージョン ${newVersion.version_number} を作成しました。`,
            });
            
            setVersions(prev => [newVersion, ...prev]);
            setActiveVersion(newVersion);

        } catch (err) {
            console.error("Failed to adjust text and create new version", err);
            updateDocumentState({ error: `AIによる調整中にエラーが発生しました: ${err instanceof Error ? err.message : 'Unknown error'}` });
        } finally {
            setIsAdjusting(false);
        }
    }, [activeVersion, currentPage, doc, user, isAdjusting, versions, updateDocumentState]);
    
    const handleContentChange = (id: string, newContent: string) => {
        if (!activeVersion) return;
        const pageKey = String(currentPage);
        const layout = activeVersion.layout_json as unknown as Record<string, StructuredContent[]>;
        const currentPageContent = layout[pageKey] || [];
        const newPageContent = currentPageContent.map(item =>
            item.id === id ? { ...item, content: newContent } : item
        );
        const newLayout = { ...layout, [pageKey]: newPageContent };
        setActiveVersion({ ...activeVersion, layout_json: newLayout as unknown as Json });
    };
  
    const handleImageSave = async (imageDataUrl: string) => {
      // This needs re-thinking as pageImages are not on the doc model.
      console.log("Image saving is disabled for now.");
      setIsEditingImage(false);
    };

    const handleExport = async () => {
        if (!activeVersion || !doc) return;
        const allContent = Object.values(activeVersion.layout_json as unknown as Record<string, StructuredContent[]>).flat();
        if (allContent.length === 0) {
            updateDocumentState({error: '書き出す内容がありません。'});
            return;
        }

        updateDocumentState({ exportStatus: 'exporting' });
        
        try {
            await new Promise(resolve => setTimeout(resolve, 500));
            const paperFormat = Object.values(PAPER_FORMATS).find(p => p.width_mm === doc?.paper_width_mm && p.height_mm === doc.paper_height_mm);
            if (!paperFormat) throw new Error("Paper format not found");

            const { blob, filename } = generateIdmlFile(allContent, paperFormat, doc?.formattingOptions!);
            const url = URL.createObjectURL(blob);
            
            updateDocumentState({ exportStatus: 'success', exportUrl: url, exportFilename: filename });

        } catch (err) {
            console.error(err);
            updateDocumentState({ exportStatus: 'error', error: 'IDMLファイルの書き出し中にエラーが発生しました。' });
        }
    };
    
    const handleFormattingChange = useCallback((newOptions: FormattingOptions) => {
        if (!doc) return;
        const newDocState = { ...doc, formattingOptions: newOptions };
        setDoc(newDocState);
        // Note: Formatting options are client-side only for now, so no DB update.
    }, [doc]);

    if (loading) return <div className="text-center p-8">読み込み中...</div>;
    if (error) return <div className="text-red-500 dark:text-red-400">エラー: {error}</div>;
    if (!doc) return <div>ドキュメントが見つかりません。</div>;
    if (doc.status === ProcessState.Processing.toString() || doc.status === ProcessState.Uploaded.toString()) {
        return <JobProgress job={doc} />
    }

    if (doc.status === ProcessState.Error.toString()) {
        return <div className="bg-red-100 dark:bg-red-900/50 text-red-700 dark:text-red-200 p-4 rounded-lg">エラー: {doc.error}</div>;
    }

    const currentStructuredContent = (activeVersion?.layout_json
        ? (activeVersion.layout_json as unknown as Record<string, StructuredContent[]>)[String(currentPage)]
        : []) || [];

    return (
        <div className="space-y-6">
             {isEditingImage && originalImageUrl && (
                <ImageEditor 
                src={originalImageUrl}
                onSave={handleImageSave}
                onClose={() => setIsEditingImage(false)}
                />
            )}

            {versions.length > 0 && (
              <div className="max-w-md bg-white dark:bg-gray-800 p-4 rounded-lg shadow">
                  <label htmlFor="version-selector" className="block text-sm font-medium text-gray-700 dark:text-gray-300">バージョン履歴</label>
                  <select
                      id="version-selector"
                      value={activeVersion?.id || ''}
                      onChange={(e) => {
                          const selectedVersion = versions.find(v => v.id === e.target.value);
                          if (selectedVersion) setActiveVersion(selectedVersion);
                      }}
                      className="mt-1 block w-full pl-3 pr-10 py-2 border border-gray-300 bg-white dark:border-gray-600 dark:bg-gray-700 dark:text-white focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 text-sm rounded-md"
                  >
                      {versions.map(v => (
                          <option key={v.id} value={v.id}>
                              Version {v.version_number} ({new Date(v.created_at).toLocaleString('ja-JP')}) - {v.changelog || '変更履歴なし'}
                          </option>
                      ))}
                  </select>
              </div>
            )}

            <DiffViewer
                imageSrc={originalImageUrl}
                onEditClick={() => setIsEditingImage(true)}
                content={currentStructuredContent}
                onContentChange={(id, content) => handleContentChange(id, content)}
                onAdjust={(prompt) => handleAdjust(prompt)}
                isLoading={isAdjusting}
                onExport={handleExport}
                exportStatus={doc.exportStatus || 'idle'}
                exportUrl={doc.exportUrl || null}
                exportFilename={doc.exportFilename || null}
                formattingOptions={doc.formattingOptions || { fontFamily: 'serif', fontSize: 12, lineHeight: 1.8 }}
                onFormattingChange={handleFormattingChange}
            />
            {doc.total_pages > 1 && (
            <Pagination
                currentPage={currentPage}
                totalPages={doc.total_pages}
                onPageChange={setCurrentPage}
            />
            )}
        </div>
    );
};

export default App;
