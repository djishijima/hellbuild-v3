import { createClient } from '@supabase/supabase-js';
import { Database } from './database.types';

const supabaseUrl = 'https://otpvwioggjhwcsnaelxn.supabase.co';
const supabaseAnonKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im90cHZ3aW9nZ2pod2NzbmFlbHhuIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTE1MTQ0NjMsImV4cCI6MjA2NzA5MDQ2M30.ep9Qphyb9FhLwn5dk_t-scu_VfKKSZXpT1qwEIln93g';

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error('Supabase URL and Anon Key are required.');
}

export const supabase = createClient<Database>(supabaseUrl, supabaseAnonKey, {
  global: {
    // Explicitly passing fetch to address "Failed to fetch" errors that can occur
    // in some environments or with certain polyfills.
    fetch: fetch.bind(globalThis)
  }
});