
import { supabase } from './supabaseClient';
import { Project, OcrDocument, OcrDocumentVersion, ProcessState } from '../types';
import { Database } from "./database.types";

const PDF_BUCKET = 'documents';
const IMAGE_BUCKET = 'documents';

const PROJECT_COLUMNS = 'id, project_name, description, client_name, status, created_at, updated_at';
const OCR_DOCUMENT_COLUMNS = 'id, project_id, title, original_filename, paper_width_mm, paper_height_mm, total_pages, current_version, created_at, updated_at, status, progress_message, processed_pages, error';
const OCR_DOCUMENT_VERSION_COLUMNS = 'id, document_id, version_number, changelog, layout_json, indd_file_url, created_by, created_at';

// Helper to convert data URL to Blob
const dataURLtoBlob = (dataurl: string) => {
    const arr = dataurl.split(',');
    const mimeMatch = arr[0].match(/:(.*?);/);
    if (!mimeMatch || !mimeMatch[1]) {
      throw new Error("Could not determine MIME type from data URL.");
    }
    const mime = mimeMatch[1];
    const bstr = atob(arr[1]);
    let n = bstr.length;
    const u8arr = new Uint8Array(n);
    while(n--){
        u8arr[n] = bstr.charCodeAt(n);
    }
    return new Blob([u8arr], {type:mime});
}

const sanitizeFileName = (name: string): string => {
  // Replaces characters that are often problematic in object keys.
  // We'll allow alphanumeric (incl. Japanese), dots, hyphens, and underscores.
  // Everything else becomes an underscore.
  // \w is for [A-Za-z0-9_]. We add Japanese and hyphens.
  return name.replace(/[^\w.\-\u3040-\u309f\u30a0-\u30ff\u4e00-\u9faf]/g, '_');
};


export const dbService = {
  // === Project Functions ===
  async getProjects(): Promise<Project[]> {
    const { data, error } = await supabase
      .from('projects')
      .select(PROJECT_COLUMNS)
      .order('created_at', { ascending: false });

    if (error) {
      const errorMessage = `Error fetching projects: ${error.message}`;
      console.error(errorMessage, error);
      throw new Error(errorMessage);
    }
    return data as unknown as Project[] || [];
  },

  async addProject(projectData: Database['public']['Tables']['projects']['Insert']): Promise<Project> {
    const { data, error } = await supabase
      .from('projects')
      .insert(projectData)
      .select(PROJECT_COLUMNS)
      .single();
    
    if (error) {
      const errorMessage = `Error adding project: ${error.message}`;
      console.error(errorMessage, error);
      throw new Error(errorMessage);
    }
    return data as unknown as Project;
  },

  // === Document Functions ===
  async getDocumentsForProject(projectId: string): Promise<OcrDocument[]> {
    const { data, error } = await supabase
      .from('ocr_documents')
      .select(OCR_DOCUMENT_COLUMNS)
      .eq('project_id', projectId)
      .order('created_at', { ascending: false });

    if (error) {
      const errorMessage = `Error fetching documents: ${error.message}`;
      console.error(errorMessage, error);
      throw new Error(errorMessage);
    }
    return (data || []).map(d => ({...d, status: d.status as ProcessState, exportStatus: 'idle'}) as OcrDocument);
  },
  
  async getDocument(documentId: string): Promise<OcrDocument | null> {
    const { data, error } = await supabase
        .from('ocr_documents')
        .select(OCR_DOCUMENT_COLUMNS)
        .eq('id', documentId)
        .single();
    if (error) {
        if (error.code !== 'PGRST116') { // Ignore "not found" errors which are expected
            console.error(`Error fetching document ${documentId}: ${error.message}`);
        }
        return null;
    }
     return data ? ({...data, status: data.status as ProcessState, exportStatus: 'idle'} as OcrDocument) : null;
  },

  async addDocument(docData: Omit<Database['public']['Tables']['ocr_documents']['Insert'], 'id' | 'created_at' | 'updated_at' | 'status' | 'current_version'>): Promise<OcrDocument> {
      const newDoc: Database['public']['Tables']['ocr_documents']['Insert'] = {
          ...docData,
          status: ProcessState.Uploaded.toString(),
          current_version: null,
      };
      const { data, error } = await supabase
        .from('ocr_documents')
        .insert(newDoc)
        .select(OCR_DOCUMENT_COLUMNS)
        .single();
    
      if (error) {
        const errorMessage = `Error adding document: ${error.message}`;
        console.error(errorMessage, error);
        throw new Error(errorMessage);
      }
      return {...data, exportStatus: 'idle'} as OcrDocument;
  },

  async updateDocument(doc: Partial<OcrDocument> & { id: string }): Promise<OcrDocument> {
      const dbUpdateData: Database['public']['Tables']['ocr_documents']['Update'] = {};

      const validKeys: (keyof Database['public']['Tables']['ocr_documents']['Update'])[] = [
        'project_id', 'title', 'original_filename', 'paper_width_mm', 'paper_height_mm',
        'total_pages', 'current_version', 'status', 'progress_message', 'processed_pages', 'error'
      ];
      
      validKeys.forEach(key => {
        if (key in doc && doc[key] !== undefined) {
          (dbUpdateData as any)[key] = doc[key];
        }
      });

      if (Object.keys(dbUpdateData).length === 0) {
        const currentDoc = await this.getDocument(doc.id);
        if (!currentDoc) throw new Error("Failed to retrieve document for no-op update.");
        return { ...currentDoc, ...doc };
      }

      const { data: updatedData, error } = await supabase
        .from('ocr_documents')
        .update(dbUpdateData)
        .eq('id', doc.id)
        .select(OCR_DOCUMENT_COLUMNS)
        .single();

      if (error) {
        const errorMessage = `Error updating document: ${error.message}`;
        console.error(errorMessage, error);
        throw new Error(errorMessage);
      }
      
      if (!updatedData) {
        throw new Error(`Document with ID ${doc.id} not found after update.`);
      }

      // Merge the updated DB data with the incoming partial `doc` to preserve client-side state
      const result = { ...updatedData, ...doc, status: updatedData.status as ProcessState };
      return result as OcrDocument;
  },

  // === Document Version Functions ===
  async getDocumentVersions(documentId: string): Promise<OcrDocumentVersion[]> {
    const { data, error } = await supabase
      .from('ocr_document_versions')
      .select(OCR_DOCUMENT_VERSION_COLUMNS)
      .eq('document_id', documentId)
      .order('version_number', { ascending: false });

    if (error) {
      const errorMessage = `Error fetching document versions: ${error.message}`;
      console.error(errorMessage, error);
      throw new Error(errorMessage);
    }
    return (data as OcrDocumentVersion[]) || [];
  },

  async addDocumentVersion(versionData: Database['public']['Tables']['ocr_document_versions']['Insert']): Promise<OcrDocumentVersion> {
    const { data, error } = await supabase
      .from('ocr_document_versions')
      .insert(versionData)
      .select(OCR_DOCUMENT_VERSION_COLUMNS)
      .single();

    if (error) {
      const errorMessage = `Error adding document version: ${error.message}`;
      console.error(errorMessage, error);
      throw new Error(errorMessage);
    }
    return data as OcrDocumentVersion;
  },
  
  // === Storage Functions ===
  async uploadPdf(file: File, userId: string, projectId: string): Promise<{ path: string }> {
      const sanitizedFileName = sanitizeFileName(file.name);
      const path = `${userId}/${projectId}/${Date.now()}-${sanitizedFileName}`;
      const { error } = await supabase.storage.from(PDF_BUCKET).upload(path, file);
      if (error) {
        console.error("PDF Upload Error:", JSON.stringify(error, null, 2));
        throw new Error(`PDFのアップロードに失敗しました: ${error.message}`);
      }
      return { path };
  },

  getPdfPublicUrl(path: string): string {
      const { data } = supabase.storage.from(PDF_BUCKET).getPublicUrl(path);
      return data.publicUrl;
  },
  
  async uploadPageImage(imageDataUrl: string, projectId: string, documentId: string, pageNum: number, userId: string): Promise<{ path: string }> {
      const blob = dataURLtoBlob(imageDataUrl);
      const path = `${userId}/${projectId}/${documentId}/page_${pageNum}.png`;
      const { error } = await supabase.storage.from(IMAGE_BUCKET).upload(path, blob, { upsert: true });
      if (error) {
        console.error("Page Image Upload Error:", error);
        throw new Error(`ページ画像のアップロードに失敗しました: ${error.message}`);
      }
      return { path };
  },

  getPageImagePublicUrl(path: string): string {
      const { data } = supabase.storage.from(IMAGE_BUCKET).getPublicUrl(path);
      return data.publicUrl;
  }
};
