
import { StructuredContent, PaperFormat, FormattingOptions } from '../types';

// Helper function to format date and time for the filename
const getFormattedTimestamp = () => {
  const now = new Date();
  const year = now.getFullYear();
  const month = (now.getMonth() + 1).toString().padStart(2, '0');
  const day = now.getDate().toString().padStart(2, '0');
  const hours = now.getHours().toString().padStart(2, '0');
  const minutes = now.getMinutes().toString().padStart(2, '0');
  return `${year}-${month}-${day}_${hours}-${minutes}`;
};

const generateIdml = (content: StructuredContent[], paperFormat: PaperFormat, formattingOptions: FormattingOptions): string => {
  const docId = `d_doc_${Date.now()}`;
  const storyId = `u_story_${Date.now()}`;
  const textFrameId = `u_frame_${Date.now()}`;
  const masterSpreadId = `u_master_${Date.now()}`;
  const spreadId = `u_spread_${Date.now()}`;

  const { width_mm, height_mm } = paperFormat;
  const margin = 20; // 20mm margin on all sides

  const frameWidth = width_mm - (margin * 2);
  const frameHeight = height_mm - (margin * 2);

  const frameY1 = margin;
  const frameX1 = margin;
  const frameY2 = frameY1 + frameHeight;
  const frameX2 = frameX1 + frameWidth;

  // For PathGeometry points (anchors are relative to frame center)
  const anchorX = frameWidth / 2;
  const anchorY = frameHeight / 2;
  
  const { fontFamily, fontSize, lineHeight } = formattingOptions;
  const fontName = fontFamily === 'serif' ? 'Noto Serif JP' : 'Noto Sans JP';

  const paragraphStyles = `
    <RootParagraphStyleGroup Self="u_root_para_style">
      <ParagraphStyle Self="ParagraphStyle/$ID/[No paragraph style]" Name="$ID/[No paragraph style]" />
      <ParagraphStyle Self="ParagraphStyle/Normal" Name="Normal" AppliedFont="${fontName}" />
      <ParagraphStyle Self="ParagraphStyle/Title" Name="Title" BasedOn="ParagraphStyle/Normal" PointSize="${fontSize * 1.5}" Leading="${fontSize * 1.5 * 1.2}" SpaceAfter="5" />
      <ParagraphStyle Self="ParagraphStyle/Author" Name="Author" BasedOn="ParagraphStyle/Normal" PointSize="${fontSize * 0.9}" FontStyle="Italic" SpaceAfter="10" />
      <ParagraphStyle Self="ParagraphStyle/Paragraph" Name="Paragraph" BasedOn="ParagraphStyle/Normal" PointSize="${fontSize}" Leading="${fontSize * lineHeight}" FirstLineIndent="${fontSize}" />
      <ParagraphStyle Self="ParagraphStyle/Annotation" Name="Annotation" BasedOn="ParagraphStyle/Normal" PointSize="${fontSize * 0.8}" FontStyle="Italic" />
    </RootParagraphStyleGroup>
  `;

  const storyContent = content.map(item => {
    const styleMap = {
      title: 'ParagraphStyle/Title',
      author: 'ParagraphStyle/Author',
      paragraph: 'ParagraphStyle/Paragraph',
      annotation: 'ParagraphStyle/Annotation',
    };
    const style = styleMap[item.type] || 'ParagraphStyle/Paragraph';
    const text = item.content.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    return `<ParagraphStyleRange AppliedParagraphStyle="${style}"><CharacterStyleRange AppliedCharacterStyle="CharacterStyle/$ID/[No character style]"><Content>${text}</Content></CharacterStyleRange><Br/></ParagraphStyleRange>`;
  }).join('');

  return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<?aid style="50" type="document" readerVersion="6.0" featureSet="257" product="16.1(0)" ?>
<Document DOMVersion="16.1" Self="${docId}" FullName="" DocumentFileName="generated.idml">
  <Properties>
    <PageColor type="enumeration">White</PageColor>
    <DocumentUserPreference PageSize="Custom" />
  </Properties>
  <Language Self="Language/$ID/Japanese" Name="$ID/Japanese" />
  <Story Self="${storyId}" AppliedTOCStyle="n" StoryTitle="$ID/" TrackChanges="false" AppliedNamedGrid="n">
    <StoryPreference OpticalMarginAlignment="false" OpticalMarginSize="12" FrameType="TextFrameType" StoryOrientation="Vertical" />
    ${storyContent}
  </Story>
  ${paragraphStyles}
  <RootCharacterStyleGroup>
    <CharacterStyle Self="CharacterStyle/$ID/[No character style]" Name="$ID/[No character style]" />
  </RootCharacterStyleGroup>
  <MasterSpread Self="${masterSpreadId}" Name="A-Master">
    <Page Self="u_page_master" AppliedMaster="n" GeometricBounds="0 0 ${height_mm} ${width_mm}" />
  </MasterSpread>
  <Spread Self="${spreadId}">
    <Page Self="u_page_1" AppliedMaster="${masterSpreadId}" PageColor="UseMasterColor" GeometricBounds="0 0 ${height_mm} ${width_mm}">
      <TextFrame Self="${textFrameId}" ParentStory="${storyId}" GeometricBounds="${frameY1} ${frameX1} ${frameY2} ${frameX2}" >
        <Properties>
          <PathGeometry>
            <GeometryPathType>
              <PointType>
                <Point Anchor="-${anchorX} -${anchorY}" />
                <Point Anchor="${anchorX} -${anchorY}" />
                <Point Anchor="${anchorX} ${anchorY}" />
                <Point Anchor="-${anchorX} ${anchorY}" />
              </PointType>
            </GeometryPathType>
          </PathGeometry>
        </Properties>
      </TextFrame>
    </Page>
  </Spread>
</Document>
  `;
};

export const generateIdmlFile = (content: StructuredContent[], paperFormat: PaperFormat, formattingOptions: FormattingOptions): { blob: Blob, filename: string } => {
  const idmlString = generateIdml(content, paperFormat, formattingOptions);
  const blob = new Blob([idmlString], { type: 'application/vnd.adobe.indesign-idml-package' });
  const filename = `古文書_${getFormattedTimestamp()}.idml`;
  return { blob, filename };
};
