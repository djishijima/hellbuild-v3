
import { StructuredContent } from '../types';

// A base64 encoded image of a Japanese manuscript snippet.
// This is a placeholder to prevent syntax errors from a truncated string.
// A real demo image would be much larger.
export const demoImage = `data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII=`;

export const demoContent: StructuredContent[] = [
  {
    id: '1678886401000',
    type: 'title',
    content: '吾輩は猫である',
    bounds: { x: 0.7, y: 0.1, width: 0.2, height: 0.4 },
  },
  {
    id: '1678886402000',
    type: 'author',
    content: '夏目漱石',
    bounds: { x: 0.45, y: 0.2, width: 0.15, height: 0.6 },
  },
  {
    id: '1678886403000',
    type: 'paragraph',
    content: '吾輩は猫である。名前はまだ無い。どこで生れたかとんと見当がつかぬ。何でも薄暗いじめじめした所でニャーニャー泣いていた事だけは記憶している。',
    bounds: { x: 0.1, y: 0.1, width: 0.25, height: 0.8 },
  },
  {
    id: '1678886404000',
    type: 'annotation',
    content: '初出：ホトゝギス',
    bounds: { x: 0.8, y: 0.8, width: 0.1, height: 0.15 },
  },
];
