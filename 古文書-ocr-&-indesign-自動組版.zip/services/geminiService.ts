
import { GoogleGenAI, GenerateContentResponse } from "@google/genai";
import { StructuredContent } from '../types';

if (!process.env.API_KEY) {
  // In a real app, you'd want to handle this more gracefully.
  // For this context, we assume the key is set.
  console.error("API_KEY environment variable not set!");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY! });

const parseJsonResponse = (text: string): any => {
    let jsonStr = text.trim();
    const fenceRegex = /^```(?:json)?\s*\n?(.*?)\n?\s*```$/s;
    const match = jsonStr.match(fenceRegex);
    if (match && match[1]) {
        jsonStr = match[1].trim();
    }
    try {
        return JSON.parse(jsonStr);
    } catch (e) {
        console.error("Failed to parse JSON response:", e);
        console.error("Original text:", text);
        throw new Error("AIから無効なJSON形式の応答がありました。");
    }
};

const crmSystemInstruction = `あなたは復刻本のOCR自動組版を支援するAIです。次のCRMシステム構造に基づいて、関連情報を出力・編集・構成しなければなりません。

CRMデータベースは以下のスキーマ構造を持ちます：
- \`ocr_documents\`: 書類メタデータ（タイトル、ページ数、PDF URL、バージョン管理）
- \`ocr_document_versions\`: バージョン別レイアウト・indd出力
- \`ocr_fonts\`: 組版に使用するフォント（名前、URL、種別）
- \`projects\`: プロジェクト単位での分類（OCR, CRM, analysis タイプ）
- \`users\`: 作成者情報（employee_id をキーに処理）
- \`nextcloud_files\`: PDFなどの添付ファイルとのリンク

あなたが出力するレイアウト・構成・ページ情報は、\`ocr_document_versions.layout_json\` に保存されます。`;


export const performOcr = async (base64ImageData: string): Promise<StructuredContent[]> => {
    const imagePart = {
        inlineData: {
            mimeType: 'image/png',
            data: base64ImageData.split(',')[1],
        },
    };

    const textPart = {
        text: `You are an expert in ancient Japanese manuscripts. The following image contains a page from a document written vertically from top to bottom, right to left. Perform OCR on this text.
        Structure the output into a JSON array of objects. Each object must have four properties:
        1. "id": A unique string identifier for the element. A timestamp-based string is good.
        2. "type": A string that can be one of 'title', 'paragraph', 'author', or 'annotation'.
        3. "content": The transcribed text content as a string.
        4. "bounds": An object with normalized coordinates { "x": number, "y": number, "width": number, "height": number } where each value is between 0 and 1, representing the bounding box of the text on the image. 'x' and 'y' are the top-left corner of the box.
        Analyze the layout to correctly identify titles (usually large, at the start), paragraphs (main body text), and any smaller annotations or author marks.
        Return only the raw JSON array, without any surrounding text or markdown fences.`
    };
    
    try {
        const response: GenerateContentResponse = await ai.models.generateContent({
            model: 'gemini-2.5-flash-preview-04-17',
            contents: { parts: [imagePart, textPart] },
            config: {
                systemInstruction: crmSystemInstruction,
                responseMimeType: 'application/json'
            }
        });

        const parsedData = parseJsonResponse(response.text);

        if (!Array.isArray(parsedData) || (parsedData.length > 0 && !parsedData.every(item => 'id' in item && 'type' in item && 'content' in item))) {
          throw new Error('AIの応答が期待される構造と異なります。基本的なプロパティ(id, type, content)が不足しています。');
        }

        return parsedData as StructuredContent[];

    } catch(error) {
        console.error("Error in performOcr:", error);
        throw error;
    }
};


export const adjustTextWithAI = async (currentStructure: StructuredContent[], prompt: string): Promise<StructuredContent[]> => {

    const systemInstruction = `${crmSystemInstruction}

You are a text editing assistant for structured documents. You will be given a JSON object representing the document's structure and a user's command.
Your task is to modify the JSON according to the command and return the new, valid JSON structure.
- IMPORTANT: Your entire response must be ONLY the modified JSON array. Do not add any explanatory text, comments, or markdown fences.
- Ensure all elements in the returned array retain the required properties: "id", "type", and "content".
- Where possible, also preserve the "bounds" property of existing elements. For new or merged elements, you can omit the "bounds" property as recalculating them is not necessary.
- Preserve the order of elements unless the command specifies otherwise.`;

    const fullPrompt = `User Command: "${prompt}"\n\nCurrent JSON Structure:\n${JSON.stringify(currentStructure, null, 2)}`;
    
    try {
        const response: GenerateContentResponse = await ai.models.generateContent({
            model: 'gemini-2.5-flash-preview-04-17',
            contents: fullPrompt,
            config: {
                systemInstruction: systemInstruction,
                responseMimeType: 'application/json'
            }
        });
        
        const parsedData = parseJsonResponse(response.text);

        if (!Array.isArray(parsedData) || (parsedData.length > 0 && !parsedData.every(item => 'id' in item && 'type' in item && 'content' in item))) {
            throw new Error('AIの応答が期待される構造と異なります。');
        }

        return parsedData as StructuredContent[];

    } catch(error) {
        console.error("Error in adjustTextWithAI:", error);
        throw error;
    }
};
