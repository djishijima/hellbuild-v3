
export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export interface Database {
  public: {
    Tables: {
      projects: {
        Row: {
          id: string
          project_name: string
          description: string | null
          client_name: string | null
          status: string | null
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          project_name: string
          description?: string | null
          client_name?: string | null
          status?: string | null
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          project_name?: string
          description?: string | null
          client_name?: string | null
          status?: string | null
          created_at?: string
          updated_at?: string
        }
      }
      ocr_documents: {
        Row: {
          id: string
          project_id: string
          title: string
          original_filename: string | null
          paper_width_mm: number
          paper_height_mm: number
          total_pages: number
          current_version: string | null
          created_at: string
          updated_at: string
          status: string
          progress_message: string | null
          processed_pages: number | null
          error: string | null
        }
        Insert: {
          id?: string
          project_id: string
          title: string
          original_filename?: string | null
          paper_width_mm: number
          paper_height_mm: number
          total_pages: number
          current_version?: string | null
          created_at?: string
          updated_at?: string
          status: string
          progress_message?: string | null
          processed_pages?: number | null
          error?: string | null
        }
        Update: {
          id?: string
          project_id?: string
          title?: string
          original_filename?: string | null
          paper_width_mm?: number
          paper_height_mm?: number
          total_pages?: number
          current_version?: string | null
          created_at?: string
          updated_at?: string
          status?: string
          progress_message?: string | null
          processed_pages?: number | null
          error?: string | null
        }
      }
      ocr_document_versions: {
        Row: {
          id: string
          document_id: string
          version_number: number
          changelog: string | null
          layout_json: Json
          indd_file_url: string | null
          created_by: string
          created_at: string
        }
        Insert: {
          id?: string
          document_id: string
          version_number: number
          changelog?: string | null
          layout_json: Json
          indd_file_url?: string | null
          created_by: string
          created_at?: string
        }
        Update: {
          id?: string
          document_id?: string
          version_number?: number
          changelog?: string | null
          layout_json?: Json
          indd_file_url?: string | null
          created_by?: string
          created_at?: string
        }
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      [_ in never]: never
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}
