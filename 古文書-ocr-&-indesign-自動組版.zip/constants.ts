import { PaperFormat, PaperFormatKey } from './types';

export const PAPER_FORMATS: Record<PaperFormatKey, PaperFormat> = {
  'Shiroku-ban': { nameJP: '四六判', width_mm: 127, height_mm: 188 },
  'Kiku-ban': { nameJP: '菊判', width_mm: 136, height_mm: 195 },
  'Shinsho-ban': { nameJP: '新書判', width_mm: 103, height_mm: 182 },
  'Bunko-ban': { nameJP: '文庫判', width_mm: 105, height_mm: 148 },
  'B6': { nameJP: 'B6判', width_mm: 128, height_mm: 182 },
  'A5': { nameJP: 'A5判', width_mm: 148, height_mm: 210 },
  'B5': { nameJP: 'B5判', width_mm: 182, height_mm: 257 },
  'AB-ban': { nameJP: 'AB判', width_mm: 210, height_mm: 257 },
};

export const PAPER_FORMAT_KEYS = Object.keys(PAPER_FORMATS) as PaperFormatKey[];

export const DEFAULT_PAPER_FORMAT: PaperFormatKey = 'Shiroku-ban';

export const FONT_FAMILY_MAP: Record<string, { name: string; value: string; }> = {
    'serif': { name: '明朝体 (Serif)', value: `'Noto Serif JP', 'Hiragino Mincho ProN', 'MS Mincho', serif` },
    'sans-serif': { name: 'ゴシック体 (Sans-serif)', value: `'Noto Sans JP', 'Hiragino Kaku Gothic ProN', 'MS Gothic', sans-serif` },
};
