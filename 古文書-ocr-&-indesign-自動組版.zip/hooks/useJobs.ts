// This file is deprecated due to a data model refactoring and is no longer used.
export {};
