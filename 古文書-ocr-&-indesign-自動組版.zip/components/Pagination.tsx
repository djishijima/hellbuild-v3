import React from 'react';
import { ChevronLeftIcon, ChevronRightIcon } from './icons';

interface PaginationProps {
  currentPage: number;
  totalPages: number;
  onPageChange: (page: number) => void;
}

const Pagination: React.FC<PaginationProps> = ({ currentPage, totalPages, onPageChange }) => {
  const handlePrevious = () => {
    if (currentPage > 1) {
      onPageChange(currentPage - 1);
    }
  };

  const handleNext = () => {
    if (currentPage < totalPages) {
      onPageChange(currentPage + 1);
    }
  };

  const getPaginationItems = (): (string | number)[] => {
    const range = (from: number, to: number) => {
      const result: number[] = [];
      for (let i = from; i <= to; i++) {
          result.push(i);
      }
      return result;
    }

    // siblingCount = 1
    // 1 (first) + 1 (last) + 1 (current) + 2 (siblings) + 2 (ellipsis) = 7
    const totalPageNumbers = 7;
    if (totalPages <= totalPageNumbers) {
        return range(1, totalPages);
    }
    
    const leftSiblingIndex = Math.max(currentPage - 1, 1);
    const rightSiblingIndex = Math.min(currentPage + 1, totalPages);
    
    const shouldShowLeftDots = leftSiblingIndex > 2;
    const shouldShowRightDots = rightSiblingIndex < totalPages - 1;

    const firstPageIndex = 1;
    const lastPageIndex = totalPages;

    if (!shouldShowLeftDots && shouldShowRightDots) {
        // [1, 2, 3, 4, 5, ..., 20]
        const leftItemCount = 5;
        const leftRange = range(1, leftItemCount);
        return [...leftRange, '...', totalPages];
    }
    
    if (shouldShowLeftDots && !shouldShowRightDots) {
        // [1, ..., 16, 17, 18, 19, 20]
        const rightItemCount = 5;
        const rightRange = range(totalPages - rightItemCount + 1, totalPages);
        return [firstPageIndex, '...', ...rightRange];
    }

    if (shouldShowLeftDots && shouldShowRightDots) {
        // [1, ..., 9, 10, 11, ..., 20]
        const middleRange = range(leftSiblingIndex, rightSiblingIndex);
        return [firstPageIndex, '...', ...middleRange, '...', lastPageIndex];
    }

    return range(1, totalPages); // fallback
  }

  const paginationItems = getPaginationItems();
  
  if (totalPages <= 1) {
    return null;
  }

  return (
    <div className="flex items-center justify-center mt-4 space-x-1">
      <button
        onClick={handlePrevious}
        disabled={currentPage <= 1}
        className="p-2 border border-transparent rounded-md text-sm font-medium text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
        aria-label="前のページへ"
      >
        <ChevronLeftIcon className="w-5 h-5" />
      </button>
      <nav className="flex items-center space-x-1" aria-label="Pagination">
        {paginationItems.map((item, index) => {
          if (typeof item === 'string') {
            return (
              <span key={`ellipsis-${index}`} className="px-2 py-2 text-sm font-medium text-gray-500 dark:text-gray-400">
                ...
              </span>
            );
          }
          const isCurrent = item === currentPage;
          return (
            <button
              key={item}
              onClick={() => onPageChange(item)}
              disabled={isCurrent}
              className={`w-9 h-9 flex items-center justify-center rounded-md text-sm font-medium transition-colors ${
                isCurrent
                  ? 'bg-indigo-600 text-white cursor-default'
                  : 'text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700'
              }`}
              aria-current={isCurrent ? 'page' : undefined}
            >
              {item}
            </button>
          );
        })}
      </nav>
      <button
        onClick={handleNext}
        disabled={currentPage >= totalPages}
        className="p-2 border border-transparent rounded-md text-sm font-medium text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
        aria-label="次のページへ"
      >
        <ChevronRightIcon className="w-5 h-5" />
      </button>
    </div>
  );
};

export default Pagination;