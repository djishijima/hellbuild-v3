
import React, { useState, useEffect } from 'react';
import { OcrDocument } from '../types';

interface JobProgressProps {
    job: OcrDocument;
}

const JobProgress: React.FC<JobProgressProps> = ({ job }) => {
    const [elapsedTime, setElapsedTime] = useState(0);

    useEffect(() => {
        const timer = setInterval(() => {
            setElapsedTime(prev => prev + 1);
        }, 1000);

        return () => clearInterval(timer);
    }, []);

    const formatTime = (seconds: number) => {
        const mins = Math.floor(seconds / 60).toString().padStart(2, '0');
        const secs = (seconds % 60).toString().padStart(2, '0');
        return `${mins}:${secs}`;
    };

    const progressPercentage = job.total_pages > 0 ? ((job.processed_pages || 0) / job.total_pages) * 100 : 0;

    return (
        <div className="max-w-2xl mx-auto bg-white dark:bg-gray-800 p-8 rounded-lg shadow-lg text-center">
            <h2 className="text-2xl font-bold text-gray-800 dark:text-white mb-4">処理を実行中...</h2>
            <p className="text-gray-600 dark:text-gray-300 mb-6">
                ブラウザタブを開いたままお待ちください。処理が完了すると結果が自動的に表示されます。
            </p>

            <div className="w-20 h-20 mx-auto border-4 border-t-4 border-t-indigo-500 border-gray-200 dark:border-gray-600 rounded-full animate-spin"></div>

            <div className="mt-8 space-y-3">
                <p className="text-lg font-medium text-gray-700 dark:text-gray-200">{job.progress_message || '準備中...'}</p>
                
                {job.total_pages > 0 && (
                  <>
                    <div className="w-full bg-gray-200 rounded-full h-4 dark:bg-gray-700 overflow-hidden">
                        <div
                            className="bg-indigo-600 h-4 rounded-full transition-all duration-500"
                            style={{ width: `${progressPercentage}%` }}
                        ></div>
                    </div>

                    <div className="flex justify-between text-sm font-medium text-gray-500 dark:text-gray-400">
                        <span>
                            ページ: {Math.min((job.processed_pages || 0) + 1, job.total_pages)} / {job.total_pages}
                        </span>
                        
                        <span>{Math.round(progressPercentage)}%</span>
                    </div>
                  </>
                )}
            </div>
            
            <div className="mt-6 pt-6 border-t border-gray-200 dark:border-gray-700 text-center">
                <p className="text-sm text-gray-500 dark:text-gray-400">経過時間: <span className="font-mono">{formatTime(elapsedTime)}</span></p>
                <p className="text-xs text-gray-400 dark:text-gray-500 mt-2">
                    ヒント: 通常、1ページあたり30秒～1分程度かかります。
                </p>
            </div>
        </div>
    );
};

export default JobProgress;
