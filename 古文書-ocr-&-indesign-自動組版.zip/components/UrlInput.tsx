import React, { useState, useCallback } from 'react';

interface UrlInputProps {
  onFileSelect: (file: File) => void;
}

const UrlInput: React.FC<UrlInputProps> = ({ onFileSelect }) => {
  const [url, setUrl] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleFetch = useCallback(async () => {
    if (!url.trim()) {
      setError('有効なURLを入力してください。');
      return;
    }
    try {
      new URL(url);
    } catch (_) {
      setError('無効なURL形式です。');
      return;
    }

    setIsLoading(true);
    setError(null);

    try {
      // Use a more reliable CORS proxy to fetch the PDF from the provided URL.
      const proxyUrl = `https://api.allorigins.win/raw?url=${encodeURIComponent(url)}`;
      const response = await fetch(proxyUrl);
      
      if (!response.ok) {
        throw new Error(`ファイルの取得に失敗しました: ${response.statusText} (${response.status})`);
      }
      
      const blob = await response.blob();
      
      if (blob.type !== 'application/pdf') {
        // If the proxy returns an error, it's often as an HTML/text page.
        if (blob.type.startsWith('text/')) {
          throw new Error('URLからPDFの取得に失敗しました。URLが正しいか、ファイルが公開されているか確認してください。');
        }
        throw new Error(`取得したファイルはPDFではありません。検出された形式: ${blob.type}`);
      }
      
      const filename = url.substring(url.lastIndexOf('/') + 1).split('?')[0] || 'document.pdf';
      const file = new File([blob], filename, { type: 'application/pdf' });
      onFileSelect(file);
    } catch (e: any) {
      setError(e.message || 'PDFの取得中に不明なエラーが発生しました。');
      console.error(e);
    } finally {
      setIsLoading(false);
    }
  }, [url, onFileSelect]);

  return (
    <div className="mt-2 space-y-3">
      <p className="text-sm text-gray-600 dark:text-gray-400">
        処理したいPDFファイルのURLを入力してください。
      </p>
      <div className="flex items-start space-x-2">
        <div className="flex-grow">
          <input
            type="url"
            value={url}
            onChange={(e) => setUrl(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter') {
                handleFetch();
              }
            }}
            placeholder="https://example.com/document.pdf"
            className="w-full p-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 bg-white dark:bg-gray-700"
            disabled={isLoading}
            aria-label="PDF URL"
            aria-describedby="url-error"
          />
          {error && <p id="url-error" className="text-red-600 text-sm mt-1">{error}</p>}
        </div>
        <button
          onClick={handleFetch}
          disabled={isLoading || !url.trim()}
          className="px-4 py-2 bg-indigo-600 text-white font-semibold rounded-lg shadow-md hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 disabled:bg-gray-400 disabled:cursor-not-allowed transition-colors shrink-0"
        >
          {isLoading ? '取得中...' : '取得'}
        </button>
      </div>
      <p className="text-xs text-gray-500 dark:text-gray-500">
        注意: サーバーのCORS設定により、一部のURLからは直接ファイルを取得できない場合があります。
      </p>
    </div>
  );
};

export default UrlInput;