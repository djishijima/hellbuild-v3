

import React, { useState, useEffect, useCallback } from 'react';
import { Project } from '../types';
import { dbService } from '../services/dbService';
import { PlusIcon, ChevronRightIcon } from './icons';
import type { User } from '@supabase/supabase-js';

interface ProjectListProps {
  user: User;
  onSelectProject: (projectId: string) => void;
  onStartCreation: () => void;
}

const ProjectList: React.FC<ProjectListProps> = ({ user, onSelectProject, onStartCreation }) => {
  const [projects, setProjects] = useState<Project[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchProjects = useCallback(async () => {
    try {
      setLoading(true);
      const fetchedProjects = await dbService.getProjects();
      setProjects(fetchedProjects);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'プロジェクトの読み込みに失敗しました。');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchProjects();
  }, [fetchProjects]);

  if (loading) return (
    <div className="text-center p-10">
      <div className="w-12 h-12 border-4 border-t-4 border-t-indigo-500 border-gray-200 dark:border-gray-600 rounded-full animate-spin mx-auto"></div>
      <p className="mt-4 text-gray-600 dark:text-gray-300">プロジェクトを読み込み中...</p>
    </div>
  );

  if (error) return <div className="text-red-500 bg-red-100 p-4 rounded-lg">エラー: {error}</div>;

  return (
    <div className="max-w-5xl mx-auto">
      <div className="flex justify-end mb-4">
        <button
          onClick={onStartCreation}
          className="flex items-center px-4 py-2 bg-indigo-600 text-white font-semibold rounded-lg shadow-md hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2"
        >
          <PlusIcon className="w-5 h-5 mr-2" />
          新規プロジェクト
        </button>
      </div>
      
      <div className="space-y-6">
        {projects.length > 0 ? projects.map(p => (
          <div 
            key={p.id}
            onClick={() => onSelectProject(p.id)}
            className="bg-white dark:bg-gray-800 shadow-lg rounded-lg overflow-hidden transition-all duration-200 hover:shadow-xl hover:ring-2 hover:ring-indigo-500 cursor-pointer"
          >
            <div className="p-4 sm:p-6 flex justify-between items-center">
              <div>
                <h2 className="text-xl font-bold text-gray-800 dark:text-white">{p.project_name}</h2>
                <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">{p.description || '説明なし'}</p>
                <p className="text-xs text-gray-400 dark:text-gray-500 mt-2">作成日: {new Date(p.created_at).toLocaleDateString()}</p>
              </div>
              <ChevronRightIcon className="w-6 h-6 text-gray-400" />
            </div>
          </div>
        )) : (
            <div className="text-center py-16 px-6 bg-white dark:bg-gray-800 rounded-lg shadow-md">
                <h3 className="text-xl font-semibold text-gray-700 dark:text-gray-200">プロジェクトがありません</h3>
                <p className="mt-2 text-gray-500 dark:text-gray-400">右上の「新規プロジェクト」ボタンから最初のプロジェクトを作成しましょう。</p>
            </div>
        )}
      </div>
    </div>
  );
};

export default ProjectList;
