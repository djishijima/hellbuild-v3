import React, { useState, useRef, useEffect } from 'react';
import StructuredEditor from './StructuredEditor';
import { StructuredContent, StructuredContentType, FormattingOptions } from '../types';
import { EditIcon } from './icons';
import type { ExportStatus } from '../types';
import { FONT_FAMILY_MAP } from '../constants';

// --- Formatting Panel Component ---
interface FormattingPanelProps {
  options: FormattingOptions;
  characterCount: number;
  onChange: (options: FormattingOptions) => void;
  disabled?: boolean;
}

const FormattingPanel: React.FC<FormattingPanelProps> = ({ options, characterCount, onChange, disabled }) => {

    const handleValueChange = (field: keyof FormattingOptions, value: any) => {
        const newOptions = { ...options, [field]: value };
        // Ensure values are numbers where expected
        if (field === 'fontSize' || field === 'lineHeight') {
            newOptions[field] = Number(value);
        }
        onChange(newOptions);
    };

    return (
        <div className="flex-grow overflow-y-auto pr-2 space-y-6">
            <div>
                <h3 className="text-lg font-semibold text-gray-700 dark:text-gray-200 mb-2">書式サマリー</h3>
                <div className="bg-gray-100 dark:bg-gray-700/50 rounded-lg p-3 space-y-2">
                    <div className="flex justify-between items-center text-sm">
                        <span className="font-medium text-gray-600 dark:text-gray-300">総文字数:</span>
                        <span className="font-mono text-gray-800 dark:text-gray-100">{characterCount.toLocaleString()} 文字</span>
                    </div>
                </div>
            </div>

            <div>
                <h3 className="text-lg font-semibold text-gray-700 dark:text-gray-200 mb-3">書式設定</h3>
                <div className="space-y-4">
                    {/* Font Family */}
                    <div>
                        <label htmlFor="fontFamily" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">フォント</label>
                        <select
                            id="fontFamily"
                            value={options.fontFamily}
                            onChange={(e) => handleValueChange('fontFamily', e.target.value)}
                            disabled={disabled}
                            className="block w-full pl-3 pr-10 py-2 border border-gray-300 bg-white dark:border-gray-600 dark:bg-gray-700 dark:text-white focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 text-sm rounded-md"
                        >
                           {Object.entries(FONT_FAMILY_MAP).map(([key, {name}]) => (
                               <option key={key} value={key}>{name}</option>
                           ))}
                        </select>
                    </div>

                    {/* Font Size */}
                    <div>
                        <label htmlFor="fontSize" className="block text-sm font-medium text-gray-700 dark:text-gray-300">基本フォントサイズ</label>
                         <div className="mt-1 flex items-center space-x-3">
                             <input
                                 type="range"
                                 id="fontSize"
                                 min="8"
                                 max="20"
                                 step="1"
                                 value={options.fontSize}
                                 onChange={(e) => handleValueChange('fontSize', e.target.value)}
                                 disabled={disabled}
                                 className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer dark:bg-gray-600"
                             />
                             <span className="font-mono w-12 text-center text-sm">{options.fontSize}pt</span>
                         </div>
                    </div>

                    {/* Line Height */}
                    <div>
                        <label htmlFor="lineHeight" className="block text-sm font-medium text-gray-700 dark:text-gray-300">行間</label>
                         <div className="mt-1 flex items-center space-x-3">
                             <input
                                 type="range"
                                 id="lineHeight"
                                 min="1.2"
                                 max="2.5"
                                 step="0.1"
                                 value={options.lineHeight}
                                 onChange={(e) => handleValueChange('lineHeight', e.target.value)}
                                 disabled={disabled}
                                 className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer dark:bg-gray-600"
                             />
                              <span className="font-mono w-12 text-center text-sm">{options.lineHeight.toFixed(1)}倍</span>
                         </div>
                    </div>
                </div>
            </div>
             <p className="text-xs text-gray-500 dark:text-gray-400 pt-4 border-t border-gray-200 dark:border-gray-700">
                ここでの設定はInDesignプレビューに反映されます。最終的なIDMLファイルにも一部のスタイル情報が書き出されます。
             </p>
        </div>
    );
};


// --- InDesign Preview Component ---
interface InDesignPreviewProps {
  content: StructuredContent[];
  highlightedId: string | null;
  onHoverItem: (id: string | null) => void;
  formattingOptions: FormattingOptions;
}

const InDesignPreview: React.FC<InDesignPreviewProps> = ({ content, highlightedId, onHoverItem, formattingOptions }) => {
    const pageStyle: React.CSSProperties = {
      fontFamily: FONT_FAMILY_MAP[formattingOptions.fontFamily]?.value || FONT_FAMILY_MAP['serif'].value,
    };
    
    const getBlockStyle = (type: StructuredContentType): React.CSSProperties => {
        const baseStyle: React.CSSProperties = {
            fontSize: `${formattingOptions.fontSize}pt`,
            lineHeight: formattingOptions.lineHeight,
        };
        switch(type) {
            case 'title':
                return { ...baseStyle, fontSize: `${formattingOptions.fontSize * 1.5}pt`, fontWeight: 'bold' };
            case 'author':
                return { ...baseStyle, fontSize: `${formattingOptions.fontSize * 0.9}pt`, fontStyle: 'italic', paddingTop: '2em' };
            case 'annotation':
                return { ...baseStyle, fontSize: `${formattingOptions.fontSize * 0.8}pt`, fontStyle: 'italic', color: '#555' };
            case 'paragraph':
            default:
                return baseStyle;
        }
    };

    return (
        <div className="flex flex-col h-full">
            <div className="flex-grow idml-preview-scroll-container">
                <div className="idml-page-preview" style={pageStyle} onMouseLeave={() => onHoverItem(null)}>
                    {content.map(item => (
                        <div
                            key={item.id}
                            onMouseEnter={() => onHoverItem(item.id)}
                            style={getBlockStyle(item.type)}
                            className={`idml-content-block ${highlightedId === item.id ? 'highlighted' : ''}`}
                        >
                            {item.content}
                        </div>
                    ))}
                </div>
            </div>
            <p className="text-xs text-gray-500 dark:text-gray-400 mt-2 text-center">
                これは最終的なIDML出力の簡易プレビューです。実際のレイアウトはInDesignで多少異なる場合があります。
            </p>
        </div>
    );
};


interface DiffViewerProps {
  imageSrc: string | null;
  onEditClick: () => void;
  content: StructuredContent[];
  onContentChange: (id: string, newContent: string) => void;
  onAdjust: (prompt: string) => void;
  isLoading: boolean;
  onExport: () => void;
  exportStatus: ExportStatus;
  exportUrl: string | null;
  exportFilename: string | null;
  formattingOptions: FormattingOptions;
  onFormattingChange: (options: FormattingOptions) => void;
}

type ViewMode = 'editor' | 'formatting' | 'preview';

const DiffViewer: React.FC<DiffViewerProps> = ({
  imageSrc,
  onEditClick,
  content,
  onContentChange,
  onAdjust,
  isLoading,
  onExport,
  exportStatus,
  exportUrl,
  exportFilename,
  formattingOptions,
  onFormattingChange
}) => {
  const [viewMode, setViewMode] = useState<ViewMode>('editor');
  const [highlightedId, setHighlightedId] = useState<string | null>(null);
  const [imageDimensions, setImageDimensions] = useState<{ width: number; height: number } | null>(null);
  const imageContainerRef = useRef<HTMLDivElement>(null);
  const imageRef = useRef<HTMLImageElement>(null);

  const highlightedItem = content.find(item => item.id === highlightedId);
  const highlightBounds = highlightedItem?.bounds;

  const characterCount = content.reduce((acc, item) => acc + item.content.length, 0);

  const updateImageDimensions = () => {
    if (imageRef.current) {
      const { clientWidth, clientHeight } = imageRef.current;
      setImageDimensions({ width: clientWidth, height: clientHeight });
    }
  };
  
  useEffect(() => {
    const img = imageRef.current;
    if (img) {
      const handleLoad = () => updateImageDimensions();
      img.addEventListener('load', handleLoad);
      if (img.complete) {
        handleLoad();
      }
      return () => img.removeEventListener('load', handleLoad);
    }
  }, [imageSrc]);

  useEffect(() => {
    const container = imageContainerRef.current;
    if (!container) return;

    const resizeObserver = new ResizeObserver(() => {
        updateImageDimensions();
    });
    resizeObserver.observe(container);
    
    return () => {
        resizeObserver.disconnect();
    };
  }, []);

  const TabButton: React.FC<{ mode: ViewMode; text: string; onClick: () => void }> = ({ mode, text, onClick }) => (
    <button
      onClick={onClick}
      className={`px-3 py-2 text-sm font-semibold rounded-md transition-colors ${
        viewMode === mode
          ? 'bg-indigo-100 dark:bg-gray-700 text-indigo-700 dark:text-white'
          : 'text-gray-500 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-700/50'
      }`}
      role="tab"
      aria-selected={viewMode === mode}
    >
      {text}
    </button>
  );

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 h-full">
      <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-lg flex flex-col max-h-[80vh]">
        <h2 className="text-xl font-semibold mb-4 text-gray-700 dark:text-gray-200 border-b pb-2">OCR対象画像</h2>
        <div ref={imageContainerRef} className="flex-grow flex items-center justify-center bg-gray-200 dark:bg-gray-700 rounded-md overflow-hidden p-2 relative" onMouseLeave={() => setHighlightedId(null)}>
            {!imageSrc && (
                 <div className="text-gray-500">画像を読み込み中...</div>
            )}
            {imageSrc && (
              <img 
                ref={imageRef} 
                src={imageSrc} 
                alt="Processed PDF page for OCR" 
                className="max-w-full max-h-full object-contain"
              />
            )}
            {imageDimensions && highlightBounds && (
              <div
                className="absolute bg-indigo-500/40 border-2 border-indigo-600 rounded-sm pointer-events-none transition-all duration-100"
                style={{
                  left: `${highlightBounds.x * imageDimensions.width}px`,
                  top: `${highlightBounds.y * imageDimensions.height}px`,
                  width: `${highlightBounds.width * imageDimensions.width}px`,
                  height: `${highlightBounds.height * imageDimensions.height}px`,
                }}
              />
            )}
            {imageSrc && (
                 <button 
                    onClick={onEditClick} 
                    className="absolute top-3 right-3 p-2 bg-black bg-opacity-50 text-white rounded-full hover:bg-opacity-75 transition-all duration-200"
                    aria-label="画像を編集"
                >
                    <EditIcon className="w-5 h-5"/>
                </button>
            )}
        </div>
      </div>
      <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-lg flex flex-col max-h-[80vh]">
        <div className="border-b border-gray-200 dark:border-gray-700">
          <div className="flex items-center p-1 rounded-lg" role="tablist" aria-label="表示モードの切り替え">
            <nav className="flex space-x-2">
              <TabButton mode="editor" text="テキスト編集" onClick={() => setViewMode('editor')} />
              <TabButton mode="formatting" text="書式設定" onClick={() => setViewMode('formatting')} />
              <TabButton mode="preview" text="InDesignプレビュー" onClick={() => setViewMode('preview')} />
            </nav>
          </div>
        </div>
        <div className="flex-grow overflow-hidden pt-4">
          {viewMode === 'editor' ? (
             <StructuredEditor
                content={content}
                onContentChange={onContentChange}
                onAdjust={onAdjust}
                onExport={onExport}
                isLoading={isLoading}
                highlightedId={highlightedId}
                onHoverItem={setHighlightedId}
                exportStatus={exportStatus}
                exportUrl={exportUrl}
                exportFilename={exportFilename}
            />
          ) : viewMode === 'formatting' ? (
              <FormattingPanel 
                options={formattingOptions}
                onChange={onFormattingChange}
                characterCount={characterCount}
                disabled={isLoading}
              />
          ) : (
            <InDesignPreview 
              content={content}
              highlightedId={highlightedId}
              onHoverItem={setHighlightedId}
              formattingOptions={formattingOptions}
            />
          )}
        </div>
      </div>
    </div>
  );
};

export default DiffViewer;
