import React from 'react';
import { PaperFormatKey } from '../types';
import { PAPER_FORMATS, PAPER_FORMAT_KEYS } from '../constants';

interface PaperFormatSelectorProps {
  selectedFormat: PaperFormatKey;
  onFormatChange: (format: PaperFormatKey) => void;
  disabled?: boolean;
}

const PaperFormatSelector: React.FC<PaperFormatSelectorProps> = ({ selectedFormat, onFormatChange, disabled }) => {
  return (
    <div>
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 mt-2">
        {PAPER_FORMAT_KEYS.map((formatKey) => {
          const format = PAPER_FORMATS[formatKey];
          const isSelected = selectedFormat === formatKey;
          return (
            <div
              key={formatKey}
              onClick={() => !disabled && onFormatChange(formatKey)}
              className={`paper-format-card relative flex flex-col items-center p-4 border-2 rounded-lg cursor-pointer ${
                isSelected ? 'border-indigo-600' : 'border-gray-300 dark:border-gray-600'
              } ${disabled ? 'opacity-50 cursor-not-allowed' : 'hover:border-indigo-500'}`}
              role="radio"
              aria-checked={isSelected}
              tabIndex={0}
              onKeyDown={(e) => {
                if (e.key === ' ' || e.key === 'Enter') {
                  e.preventDefault();
                  !disabled && onFormatChange(formatKey);
                }
              }}
            >
              <div className="text-center">
                <p className="font-semibold text-gray-800 dark:text-gray-200">{format.nameJP}</p>
                <p className="text-xs text-gray-500 dark:text-gray-400">({formatKey})</p>
              </div>
              <div 
                className="paper-format-visual my-3"
                style={{
                  width: '60px',
                  height: `${(format.height_mm / format.width_mm) * 60}px`,
                  maxHeight: '100px'
                }}
              >
              </div>
              <p className="text-sm text-gray-600 dark:text-gray-300">
                {format.width_mm} x {format.height_mm} mm
              </p>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default PaperFormatSelector;