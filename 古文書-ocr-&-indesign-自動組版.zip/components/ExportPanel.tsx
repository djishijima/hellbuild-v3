import React from 'react';
import { ExportIcon, CheckIcon, XIcon } from './icons';
import type { ExportStatus } from '../types';

interface ExportPanelProps {
  status: ExportStatus;
  onExport: () => void;
  downloadUrl: string | null;
  fileName: string | null;
  disabled: boolean;
}

const ExportPanel: React.FC<ExportPanelProps> = ({ status, onExport, downloadUrl, fileName, disabled }) => {
  const handleExportClick = () => {
    if (status !== 'exporting') {
      onExport();
    }
  };

  const renderContent = () => {
    switch (status) {
      case 'exporting':
        return (
          <div className="flex items-center justify-center w-full mt-2 px-4 py-3 bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-200 font-bold rounded-lg shadow-inner">
            <div className="w-5 h-5 border-2 border-t-2 border-t-indigo-500 border-gray-400 rounded-full animate-spin mr-3"></div>
            <span>書き出し中...</span>
          </div>
        );
      case 'success':
        return (
           <div className="flex items-center justify-between w-full mt-2 px-4 py-3 bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200 font-semibold rounded-lg shadow-inner">
            <div className="flex items-center">
                <CheckIcon className="w-5 h-5 mr-2"/>
                <span>書き出し完了</span>
            </div>
            <a
              href={downloadUrl!}
              download={fileName!}
              className="px-4 py-1 bg-green-600 text-white rounded-md hover:bg-green-700 text-sm"
            >
              ダウンロード
            </a>
          </div>
        );
      case 'error':
        return (
          <div className="flex items-center justify-between w-full mt-2 px-4 py-3 bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200 font-semibold rounded-lg shadow-inner">
            <div className="flex items-center">
                <XIcon className="w-5 h-5 mr-2"/>
                <span>エラーが発生しました</span>
            </div>
            <button
              onClick={handleExportClick}
              className="px-4 py-1 bg-red-600 text-white rounded-md hover:bg-red-700 text-sm"
            >
              再試行
            </button>
          </div>
        );
      case 'idle':
      default:
        return (
          <button
            onClick={handleExportClick}
            disabled={disabled}
            className="w-full mt-2 px-4 py-3 bg-blue-600 text-white font-bold rounded-lg shadow-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 disabled:bg-gray-400 disabled:cursor-not-allowed flex items-center justify-center"
          >
            <ExportIcon className="w-5 h-5 mr-2" />
            <span>InDesignへ書き出し (.idml)</span>
          </button>
        );
    }
  };

  return <div className="h-16">{renderContent()}</div>;
};

export default ExportPanel;
