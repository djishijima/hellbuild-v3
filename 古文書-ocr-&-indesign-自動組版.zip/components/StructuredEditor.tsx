import React, { useState } from 'react';
import { StructuredContent, StructuredContentType } from '../types';
import { AdjustIcon } from './icons';
import ExportPanel from './ExportPanel';
import type { ExportStatus } from '../types';

interface StructuredEditorProps {
  content: StructuredContent[];
  onContentChange: (id: string, newContent: string) => void;
  onAdjust: (prompt: string) => void;
  isLoading: boolean;
  highlightedId: string | null;
  onHoverItem: (id: string | null) => void;
  // Export related props
  onExport: () => void;
  exportStatus: ExportStatus;
  exportUrl: string | null;
  exportFilename: string | null;

}

const typeToLabelMap: Record<StructuredContentType, string> = {
  title: 'タイトル',
  paragraph: '段落',
  author: '著者',
  annotation: '注釈',
};

const typeToColorMap: Record<StructuredContentType, string> = {
  title: 'bg-blue-100 dark:bg-blue-900 border-blue-500',
  paragraph: 'bg-gray-50 dark:bg-gray-700 border-gray-300 dark:border-gray-600',
  author: 'bg-green-100 dark:bg-green-900 border-green-500',
  annotation: 'bg-yellow-100 dark:bg-yellow-900 border-yellow-500',
};

const StructuredEditor: React.FC<StructuredEditorProps> = ({
  content,
  onContentChange,
  onAdjust,
  isLoading,
  highlightedId,
  onHoverItem,
  onExport,
  exportStatus,
  exportUrl,
  exportFilename,
}) => {
  const [prompt, setPrompt] = useState('');

  const handleAdjustClick = () => {
    if (prompt.trim()) {
      onAdjust(prompt);
      setPrompt('');
    }
  };

  const typeCounts = new Map<StructuredContentType, number>();
  
  return (
    <div className="flex flex-col h-full">
      <div className="flex-grow overflow-y-auto pr-2 space-y-4" onMouseLeave={() => onHoverItem(null)}>
        {content.map(item => {
          const count = typeCounts.get(item.type) || 0;
          typeCounts.set(item.type, count + 1);
          const label = `${typeToLabelMap[item.type] || 'テキスト'} ${count + 1}`;

          return (
            <div
              key={item.id}
              className={`flex flex-col rounded-md transition-colors duration-200 p-1 ${
                highlightedId === item.id ? 'bg-indigo-100 dark:bg-indigo-900/50' : ''
              }`}
              onMouseEnter={() => onHoverItem(item.id)}
            >
              <label className={`text-sm font-bold text-gray-600 dark:text-gray-300 px-2 py-1 rounded-t-md ${typeToColorMap[item.type].split(' ')[0]}`}>
                {label}
              </label>
              <textarea
                value={item.content}
                onChange={e => onContentChange(item.id, e.target.value)}
                className={`w-full p-2 border-l-4 rounded-b-md focus:outline-none focus:ring-2 focus:ring-indigo-500 text-gray-800 dark:text-gray-200 resize-y ${typeToColorMap[item.type]}`}
                rows={Math.max(2, Math.ceil(item.content.length / 50))}
              />
            </div>
          );
        })}
      </div>
      <div className="mt-6 border-t pt-4 space-y-4">
        <div>
          <h3 className="text-lg font-semibold text-gray-700 dark:text-gray-200">AIで調整</h3>
          <p className="text-sm text-gray-500 dark:text-gray-400">例：「最初の2つの段落を結合して」「著者名を『山田太郎』に変更」</p>
          <div className="flex items-center mt-2 space-x-2">
            <input
              type="text"
              value={prompt}
              onChange={e => setPrompt(e.target.value)}
              placeholder="調整の指示を入力してください..."
              className="flex-grow p-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 bg-white dark:bg-gray-700"
              disabled={isLoading}
            />
            <button
              onClick={handleAdjustClick}
              disabled={isLoading || !prompt.trim()}
              className="p-2 bg-green-600 text-white rounded-lg hover:bg-green-700 disabled:bg-gray-400 disabled:cursor-not-allowed flex items-center"
            >
              <AdjustIcon className="w-5 h-5 mr-1"/>
              <span>調整</span>
            </button>
          </div>
        </div>
        <div>
           <h3 className="text-lg font-semibold text-gray-700 dark:text-gray-200">ステップ3: 書き出し</h3>
           <ExportPanel 
             status={exportStatus}
             onExport={onExport}
             downloadUrl={exportUrl}
             fileName={exportFilename}
             disabled={isLoading || content.length === 0}
           />
        </div>
      </div>
    </div>
  );
};

export default StructuredEditor;