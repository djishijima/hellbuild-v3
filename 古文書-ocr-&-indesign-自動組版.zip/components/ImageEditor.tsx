import React, { useRef } from 'react';
import Cropper, { ReactCropperElement } from 'react-cropper';
import { RotateCcwIcon, RotateCwIcon, CheckIcon, XIcon } from './icons';

interface ImageEditorProps {
  src: string;
  onSave: (dataUrl: string) => void;
  onClose: () => void;
}

const ImageEditor: React.FC<ImageEditorProps> = ({ src, onSave, onClose }) => {
  const cropperRef = useRef<ReactCropperElement>(null);

  const handleRotate = (degrees: number) => {
    const cropper = cropperRef.current?.cropper;
    if (cropper) {
      cropper.rotate(degrees);
    }
  };

  const handleSave = () => {
    const cropper = cropperRef.current?.cropper;
    if (cropper) {
      onSave(cropper.getCroppedCanvas().toDataURL('image/png'));
    }
  };

  return (
    <div className="fixed inset-0 bg-gray-900 bg-opacity-75 flex items-center justify-center z-50 p-4">
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-2xl w-full max-w-4xl max-h-[90vh] flex flex-col">
        <div className="p-4 border-b border-gray-200 dark:border-gray-700 flex justify-between items-center">
          <h2 className="text-xl font-bold text-gray-800 dark:text-white">画像のトリミングと回転</h2>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-200">
            <XIcon className="w-6 h-6" />
          </button>
        </div>
        <div className="flex-grow p-4 overflow-hidden">
          <Cropper
            ref={cropperRef}
            src={src}
            style={{ height: '100%', width: '100%' }}
            aspectRatio={NaN} // free crop
            viewMode={1}
            guides={true}
            background={false}
            responsive={true}
            autoCrop={false}
            checkOrientation={false} // important for manual rotation
          />
        </div>
        <div className="p-4 border-t border-gray-200 dark:border-gray-700 flex justify-between items-center flex-wrap gap-2">
           <div className="flex items-center space-x-2">
             <button onClick={() => handleRotate(-90)} className="p-2 bg-gray-200 dark:bg-gray-700 rounded-lg hover:bg-gray-300 dark:hover:bg-gray-600 flex items-center" aria-label="左に90度回転">
                <RotateCcwIcon className="w-5 h-5"/>
             </button>
              <button onClick={() => handleRotate(90)} className="p-2 bg-gray-200 dark:bg-gray-700 rounded-lg hover:bg-gray-300 dark:hover:bg-gray-600 flex items-center" aria-label="右に90度回転">
                <RotateCwIcon className="w-5 h-5"/>
             </button>
           </div>
           <div className="flex items-center space-x-2">
              <button onClick={onClose} className="px-4 py-2 bg-gray-500 text-white font-semibold rounded-lg hover:bg-gray-600 flex items-center">
                <XIcon className="w-5 h-5 mr-1" />
                <span>キャンセル</span>
              </button>
              <button onClick={handleSave} className="px-4 py-2 bg-indigo-600 text-white font-semibold rounded-lg hover:bg-indigo-700 flex items-center">
                <CheckIcon className="w-5 h-5 mr-1" />
                <span>保存</span>
              </button>
           </div>
        </div>
      </div>
    </div>
  );
};

export default ImageEditor;